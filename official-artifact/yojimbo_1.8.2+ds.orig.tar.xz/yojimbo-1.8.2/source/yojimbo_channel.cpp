/*
    Yojimbo Client/Server Network Library.

    Copyright © 2016 - 2026, Más Bandwidth LLC.

    Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

        1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

        2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer 
           in the documentation and/or other materials provided with the distribution.

        3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived 
           from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
    USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "yojimbo_channel.h"

namespace yojimbo
{
    void ChannelPacketData::Initialize()
    {
        channelIndex = 0;
        blockMessage = 0;
        messageFailedToSerialize = 0;
        // Fully initialize both arms so Free() and any reader are safe no matter which one the
        // serializer populates (or if it bails out early, e.g. a block fragment on a
        // disableBlocks channel).
        message.numMessages = 0;
        message.messages = NULL;
        block.message = NULL;
        block.fragmentData = NULL;
        block.messageId = 0;
        block.fragmentId = 0;
        block.fragmentSize = 0;
        block.numFragments = 0;
        block.messageType = 0;
        initialized = 1;
    }

    void ChannelPacketData::Free( MessageFactory & messageFactory )
    {
        yojimbo_assert( initialized );
        Allocator & allocator = messageFactory.GetAllocator();
        if ( !blockMessage )
        {
            if ( message.numMessages > 0 )
            {
                for ( int i = 0; i < message.numMessages; ++i )
                {
                    if ( message.messages[i] )
                    {
                        messageFactory.ReleaseMessage( message.messages[i] );
                    }
                }
                YOJIMBO_FREE( allocator, message.messages );
            }
        }
        else
        {
            if ( block.message )
            {
                messageFactory.ReleaseMessage( block.message );
                block.message = NULL;
            }
            YOJIMBO_FREE( allocator, block.fragmentData );
        }
        initialized = 0;
    }

    template <typename Stream> bool SerializeOrderedMessagesInternal( Stream & stream,
                                                                      MessageFactory & messageFactory,
                                                                      int & numMessages,
                                                                      Message ** & messages,
                                                                      int * messageTypes,
                                                                      uint16_t * messageIds )
    {
        const int maxMessageType = messageFactory.GetNumTypes() - 1;

        memset( messageTypes, 0, sizeof( int ) * numMessages );
        memset( messageIds, 0, sizeof( uint16_t ) * numMessages );

        if ( Stream::IsWriting )
        {
            yojimbo_assert( messages );

            for ( int i = 0; i < numMessages; ++i )
            {
                yojimbo_assert( messages[i] );
                messageTypes[i] = messages[i]->GetType();
                messageIds[i] = messages[i]->GetId();
            }
        }
        else
        {
            Allocator & allocator = messageFactory.GetAllocator();

            messages = (Message**) YOJIMBO_ALLOCATE( allocator, sizeof( Message* ) * numMessages );

            if ( !messages )
            {
                // Out of memory. Leave the arm empty (numMessages = 0) so ChannelPacketData::Free
                // stays safe, then fail the read; the channel treats this as a serialize failure.
                numMessages = 0;
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to allocate messages (SerializeOrderedMessages)\n" );
                return false;
            }

            for ( int i = 0; i < numMessages; ++i )
            {
                messages[i] = NULL;
            }
        }

        serialize_bits( stream, messageIds[0], 16 );

        for ( int i = 1; i < numMessages; ++i )
            serialize_sequence_relative( stream, messageIds[i-1], messageIds[i] );

        for ( int i = 0; i < numMessages; ++i )
        {
            if ( maxMessageType > 0 )
            {
                serialize_int( stream, messageTypes[i], 0, maxMessageType );
            }
            else
            {
                messageTypes[i] = 0;
            }

            if ( Stream::IsReading )
            {
                messages[i] = messageFactory.CreateMessage( messageTypes[i] );

                if ( !messages[i] )
                {
                    yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to create message of type %d (SerializeOrderedMessages)\n", messageTypes[i] );
                    return false;
                }

                messages[i]->SetId( messageIds[i] );
            }

            yojimbo_assert( messages[i] );

            if ( !messages[i]->SerializeInternal( stream ) )
            {
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to serialize message of type %d (SerializeOrderedMessages)\n", messageTypes[i] );
                return false;
            }
        }

        return true;
    }

    template <typename Stream> bool SerializeOrderedMessages( Stream & stream,
                                                              MessageFactory & messageFactory,
                                                              int & numMessages,
                                                              Message ** & messages,
                                                              int maxMessagesPerPacket )
    {
        bool hasMessages = Stream::IsWriting && numMessages != 0;

        serialize_bool( stream, hasMessages );

        if ( !hasMessages )
            return true;

        serialize_int( stream, numMessages, 1, maxMessagesPerPacket );

        // One heap block for the message type and id scratch arrays, so stack usage doesn't
        // scale with maxMessagesPerPacket. The serialize body lives in a separate function so
        // all its early returns (including the ones hidden inside serialize_* macros) funnel
        // through the single free below.
        Allocator & allocator = messageFactory.GetAllocator();

        uint8_t * scratch = (uint8_t*) YOJIMBO_ALLOCATE( allocator, ( sizeof( int ) + sizeof( uint16_t ) ) * numMessages );

        if ( !scratch )
        {
            if ( Stream::IsReading )
            {
                // Leave the arm empty (numMessages = 0) so ChannelPacketData::Free stays safe.
                // On write the messages remain owned by the packet data, so leave them alone.
                numMessages = 0;
            }
            yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to allocate serialize scratch (SerializeOrderedMessages)\n" );
            return false;
        }

        int * messageTypes = (int*) scratch;
        uint16_t * messageIds = (uint16_t*) ( scratch + sizeof( int ) * numMessages );

        const bool result = SerializeOrderedMessagesInternal( stream, messageFactory, numMessages, messages, messageTypes, messageIds );

        YOJIMBO_FREE( allocator, scratch );

        return result;
    }

    template <typename Stream> bool SerializeUnorderedMessagesInternal( Stream & stream,
                                                                        MessageFactory & messageFactory,
                                                                        int & numMessages,
                                                                        Message ** & messages,
                                                                        int maxBlockSize,
                                                                        int * messageTypes )
    {
        const int maxMessageType = messageFactory.GetNumTypes() - 1;

        memset( messageTypes, 0, sizeof( int ) * numMessages );

        if ( Stream::IsWriting )
        {
            yojimbo_assert( messages );

            for ( int i = 0; i < numMessages; ++i )
            {
                yojimbo_assert( messages[i] );
                messageTypes[i] = messages[i]->GetType();
            }
        }
        else
        {
            Allocator & allocator = messageFactory.GetAllocator();

            messages = (Message**) YOJIMBO_ALLOCATE( allocator, sizeof( Message* ) * numMessages );

            if ( !messages )
            {
                // Out of memory. Leave the arm empty (numMessages = 0) so ChannelPacketData::Free
                // stays safe, then fail the read; the channel treats this as a serialize failure.
                numMessages = 0;
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to allocate messages (SerializeUnorderedMessages)\n" );
                return false;
            }

            for ( int i = 0; i < numMessages; ++i )
                messages[i] = NULL;
        }

        for ( int i = 0; i < numMessages; ++i )
        {
            if ( maxMessageType > 0 )
            {
                serialize_int( stream, messageTypes[i], 0, maxMessageType );
            }
            else
            {
                messageTypes[i] = 0;
            }

            if ( Stream::IsReading )
            {
                messages[i] = messageFactory.CreateMessage( messageTypes[i] );

                if ( !messages[i] )
                {
                    yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to create message type %d (SerializeUnorderedMessages)\n", messageTypes[i] );
                    return false;
                }
            }

            yojimbo_assert( messages[i] );

            if ( !messages[i]->SerializeInternal( stream ) )
            {
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to serialize message type %d (SerializeUnorderedMessages)\n", messageTypes[i] );
                return false;
            }

            if ( messages[i]->IsBlockMessage() )
            {
                BlockMessage * blockMessage = (BlockMessage*) messages[i];
                if ( !SerializeMessageBlock( stream, messageFactory, blockMessage, maxBlockSize ) )
                {
                    yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to serialize message block (SerializeUnorderedMessages)\n" );
                    return false;
                }
            }
        }

        return true;
    }

    template <typename Stream> bool SerializeUnorderedMessages( Stream & stream,
                                                                MessageFactory & messageFactory,
                                                                int & numMessages,
                                                                Message ** & messages,
                                                                int maxMessagesPerPacket,
                                                                int maxBlockSize )
    {
        bool hasMessages = Stream::IsWriting && numMessages != 0;

        serialize_bool( stream, hasMessages );

        if ( !hasMessages )
            return true;

        serialize_int( stream, numMessages, 1, maxMessagesPerPacket );

        // Heap scratch for the message types, so stack usage doesn't scale with
        // maxMessagesPerPacket. The serialize body lives in a separate function so all its
        // early returns (including the ones hidden inside serialize_* macros) funnel through
        // the single free below.
        Allocator & allocator = messageFactory.GetAllocator();

        int * messageTypes = (int*) YOJIMBO_ALLOCATE( allocator, sizeof( int ) * numMessages );

        if ( !messageTypes )
        {
            if ( Stream::IsReading )
            {
                // Leave the arm empty (numMessages = 0) so ChannelPacketData::Free stays safe.
                // On write the messages remain owned by the packet data, so leave them alone.
                numMessages = 0;
            }
            yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to allocate serialize scratch (SerializeUnorderedMessages)\n" );
            return false;
        }

        const bool result = SerializeUnorderedMessagesInternal( stream, messageFactory, numMessages, messages, maxBlockSize, messageTypes );

        YOJIMBO_FREE( allocator, messageTypes );

        return result;
    }

    template <typename Stream> bool SerializeBlockFragment( Stream & stream, 
                                                            MessageFactory & messageFactory, 
                                                            ChannelPacketData::BlockData & block, 
                                                            const ChannelConfig & channelConfig )
    {
        const int maxMessageType = messageFactory.GetNumTypes() - 1;

        if (Stream::IsReading)
        {
            block.message = NULL;
            block.fragmentData = NULL;
            // messageType is only serialized with fragment 0 (below); default it so a
            // non-zero fragment leaves it defined rather than read uninitialized by callers.
            block.messageType = 0;
        }

        serialize_bits( stream, block.messageId, 16 );

        if ( channelConfig.GetMaxFragmentsPerBlock() > 1 )
        {
            serialize_int( stream, block.numFragments, 1, channelConfig.GetMaxFragmentsPerBlock() );
        }
        else
        {
            if ( Stream::IsReading )
                block.numFragments = 1;
        }

        if ( block.numFragments > 1 )
        {
            serialize_int( stream, block.fragmentId, 0, block.numFragments - 1 );
        }
        else
        {
            if ( Stream::IsReading )
                block.fragmentId = 0;
        }

        serialize_int( stream, block.fragmentSize, 1, channelConfig.blockFragmentSize );

        if ( Stream::IsReading )
        {
            block.fragmentData = (uint8_t*) YOJIMBO_ALLOCATE( messageFactory.GetAllocator(), block.fragmentSize );

            if ( !block.fragmentData )
            {
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to serialize block fragment (SerializeBlockFragment)\n" );
                return false;
            }
        }

        serialize_bytes( stream, block.fragmentData, block.fragmentSize );

        if ( block.fragmentId == 0 )
        {
            // block message

            if ( maxMessageType > 0 )
            {
                serialize_int( stream, block.messageType, 0, maxMessageType );
            }
            else
            {
                block.messageType = 0;
            }

            if ( Stream::IsReading )
            {
                Message * message = messageFactory.CreateMessage( block.messageType );

                if ( !message )
                {
                    yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to create block message type %d (SerializeBlockFragment)\n", block.messageType );
                    return false;
                }

                if ( !message->IsBlockMessage() )
                {
                    yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: received block fragment attached to non-block message (SerializeBlockFragment)\n" );
                    messageFactory.ReleaseMessage( message );
                    return false;
                }

                block.message = (BlockMessage*) message;
            }

            yojimbo_assert( block.message );

            if ( !block.message->SerializeInternal( stream ) )
            {
                yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "error: failed to serialize block message of type %d (SerializeBlockFragment)\n", block.messageType );
                return false;
            }
        }

        return true;
    }

    template <typename Stream> bool ChannelPacketData::Serialize( Stream & stream, 
                                                                  MessageFactory & messageFactory, 
                                                                  const ChannelConfig * channelConfigs, 
                                                                  int numChannels )
    {
        yojimbo_assert( initialized );

#if YOJIMBO_DEBUG_MESSAGE_BUDGET
        int startBits = stream.GetBitsProcessed();
#endif // #if YOJIMBO_DEBUG_MESSAGE_BUDGET

        if ( numChannels > 1 )
            serialize_int( stream, channelIndex, 0, numChannels - 1 );
        else
            channelIndex = 0;

        const ChannelConfig & channelConfig = channelConfigs[channelIndex];

        serialize_bool( stream, blockMessage );

        if ( !blockMessage )
        {
            switch ( channelConfig.type )
            {
                case CHANNEL_TYPE_RELIABLE_ORDERED:
                {
                    if ( !SerializeOrderedMessages( stream, messageFactory, message.numMessages, message.messages, channelConfig.maxMessagesPerPacket ) )
                    {
                        messageFailedToSerialize = 1;
                        return true;
                    }
                }
                break;

                case CHANNEL_TYPE_UNRELIABLE_UNORDERED:
                {
                    if ( !SerializeUnorderedMessages( stream, 
                                                      messageFactory, 
                                                      message.numMessages, 
                                                      message.messages, 
                                                      channelConfig.maxMessagesPerPacket, 
                                                      channelConfig.maxBlockSize ) )
                    {
                        messageFailedToSerialize = 1;
                        return true;
                    }
                }
                break;
            }

#if YOJIMBO_DEBUG_MESSAGE_BUDGET
            // Only assert on write/measure: this validates that *we* stay within the packet
            // budget when producing a packet. On read the data is untrusted (post-decrypt, but
            // still attacker-controlled), so a peer that ignores the budget must not be able to
            // crash a debug build — the message count and sizes are already bounded by the
            // serialize_* range checks, so an over-budget read is harmless, just larger.
            if ( !Stream::IsReading && channelConfig.packetBudget > 0 )
            {
                yojimbo_assert( stream.GetBitsProcessed() - startBits <= channelConfig.packetBudget * 8 );
            }
#endif // #if YOJIMBO_DEBUG_MESSAGE_BUDGET
        }
        else
        {
            if ( channelConfig.disableBlocks )
                return false;

            if ( !SerializeBlockFragment( stream, messageFactory, block, channelConfig ) )
                return false;
        }

        return true;
    }

    bool ChannelPacketData::SerializeInternal( ReadStream & stream, MessageFactory & messageFactory, const ChannelConfig * channelConfigs, int numChannels )
    {
        return Serialize( stream, messageFactory, channelConfigs, numChannels );
    }

    bool ChannelPacketData::SerializeInternal( WriteStream & stream, MessageFactory & messageFactory, const ChannelConfig * channelConfigs, int numChannels )
    {
        return Serialize( stream, messageFactory, channelConfigs, numChannels );
    }

    bool ChannelPacketData::SerializeInternal( MeasureStream & stream, MessageFactory & messageFactory, const ChannelConfig * channelConfigs, int numChannels )
    {
        return Serialize( stream, messageFactory, channelConfigs, numChannels );
    }

    // ------------------------------------------------------------------------------------

    Channel::Channel( Allocator & allocator, MessageFactory & messageFactory, const ChannelConfig & config, const int maxPacketSize, int channelIndex, double time ) : m_config( config ), m_maxPacketSize( maxPacketSize )
    {
        yojimbo_assert( channelIndex >= 0 );
        yojimbo_assert( channelIndex < MaxChannels );
        m_channelIndex = channelIndex;
        m_allocator = &allocator;
        m_messageFactory = &messageFactory;
        m_errorLevel = CHANNEL_ERROR_NONE;
        m_time = time;
        ResetCounters();
    }

    uint64_t Channel::GetCounter( int index ) const
    {
        yojimbo_assert( index >= 0 );
        yojimbo_assert( index < CHANNEL_COUNTER_NUM_COUNTERS );
        return m_counters[index];
    }

    void Channel::ResetCounters()
    { 
        memset( m_counters, 0, sizeof( m_counters ) ); 
    }

    int Channel::GetChannelIndex() const 
    { 
        return m_channelIndex;
    }

    void Channel::SetErrorLevel( ChannelErrorLevel errorLevel )
    {
        if ( errorLevel != m_errorLevel && errorLevel != CHANNEL_ERROR_NONE )
        {
            yojimbo_printf( YOJIMBO_LOG_LEVEL_ERROR, "channel went into error state: %s\n", GetChannelErrorString( errorLevel ) );
        }
        m_errorLevel = errorLevel;
    }

    ChannelErrorLevel Channel::GetErrorLevel() const
    {
        return m_errorLevel;
    }
}
